#pragma once
#include<WS2tcpip.h>
#include<iostream>
#pragma comment(lib,"ws2_32.lib")
#include<string>
#include<vector>
#include<fstream>
#include"lista_master.h"
#pragma warning(disable:4996)
#define MAX_BUFFER_SIZE (1000000000)
using namespace std;

class CTCpListener;

typedef void (*MessageReceiverHandler)(CTCpListener *listener, int socketId, std::string msg);

//class CTcpListener;

class CTCpListener
{public:
	CTCpListener(string ipAdress, int port1,int port2, MessageReceiverHandler handler);
	~CTCpListener();
	void Send(int clientSocket, std::string msg);
	
	//initializam winsock
	bool Init();

	void Run();

	void Cleanup();

	void DisplayAllMessages();

	void HandleMessages(string mesaj,int bytesReceived, char* buf);
	//void ReceiveFile(const std::string& filename,int bytesReceived, char*buf);
	void ReceiveFile1(int bytesReceived, char* buf);// pentru a primi numele fisierului, val hash, zona unde va fi stocata
	//void ReceiveFile2(int bytesReceived, char* buf);//pentru a scrie continutul fisierului
	string ReceiveCerere1();

	
	//creeam socketul
	//asteptam o conexiune
	//receive loop
	//trimitem inapoi mesajul
	//cleanup
private:
	SOCKET CreateSocket();
	SOCKET WaitForConnection(SOCKET listening);
	std::string m_ipAdress;
	int m_port1;
	int m_port2;
	MessageReceiverHandler MesajPrimit;
	struct Logare {
		string nume;
		string parola;
	};
	vector<Logare> vectorLogare;
	vector<string> vectorCerere;
	vector<lista_master> lista;
	//string verificare="null";
	string listaCatreClient;
	int aux = 0;
};