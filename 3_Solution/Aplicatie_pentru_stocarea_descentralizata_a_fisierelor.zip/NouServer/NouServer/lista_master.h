#pragma once
#include<iostream>
#include<string>
#include<stdlib.h>
using namespace std;

class lista_master
{protected:
	string nume_fisier;
	string valhash;
	string zonaMem;
	string continutFisier;
public:
	lista_master();
	lista_master(string n, string v, string z) : nume_fisier(n), valhash(v), zonaMem(z){};
	void AddContinut(string c)
	{
		continutFisier = c;
	}
	string return3() {
		string s = nume_fisier + " " + valhash + " " + zonaMem;
		return s;
	}
	string returnContinut()
	{
		return continutFisier;
	}
	void print() { cout << nume_fisier << " " << valhash << " " << zonaMem; }
};