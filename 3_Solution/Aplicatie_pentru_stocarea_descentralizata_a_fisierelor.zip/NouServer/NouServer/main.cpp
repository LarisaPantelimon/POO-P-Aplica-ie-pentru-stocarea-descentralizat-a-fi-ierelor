#include<iostream>
#include<string>
#include"tcplistener.h"

using namespace std;

void Listener_MessageReceived(CTCpListener* listener, int client, string msg);//de cine asculta, catre cine trimite, ce mesaj trimite

void main() 
{
	
	CTCpListener server("127.0.0.1", 55000,55001, Listener_MessageReceived);
	if (server.Init())
	{
		server.Run();
	}

}
void Listener_MessageReceived(CTCpListener *listener, int client, string msg)
{
	listener->Send(client, msg);
}
