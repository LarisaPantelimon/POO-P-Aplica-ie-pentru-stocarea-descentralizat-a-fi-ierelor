#include"tcplistener.h"

CTCpListener::CTCpListener(std::string ipAdress, int port1,int port2, MessageReceiverHandler handler)
	:m_ipAdress(ipAdress),m_port1(port1),m_port2(port2),MesajPrimit(handler)
{}

CTCpListener::~CTCpListener()
{
	Cleanup();
}
void CTCpListener:: Send(int clientSocket, std::string msg)
{
	send(clientSocket, msg.c_str(), msg.size() + 1, 0);
}

//initializam winsock
bool CTCpListener::Init()
{
	WSAData data;
	WORD ver = MAKEWORD(2, 2);
	int wsInit = WSAStartup(ver, &data);

	return wsInit == 0;
}
void CTCpListener::Run()
{
	char *buf=new char[MAX_BUFFER_SIZE];
	//string buffer;
	cout << "S-a deschis serverul!\n";
	SOCKET listening2 = CreateSocket();

	if (listening2 == INVALID_SOCKET)
	{
		exit(0);
	}

	SOCKET client2 = WaitForConnection(listening2);
	if (client2 != INVALID_SOCKET) cout << "Zona de memorie conectata!\n";
	SOCKET listening = CreateSocket();
	if (listening == INVALID_SOCKET)
	{
		exit(0);
	}

	while (true)
	{
		if (client2 != INVALID_SOCKET)
		{
			if (!lista.empty()) {
				for (int i = 0; i < lista.size(); i++) {
					//verific sa vad daca nu cumva a mai fost adaugat deja fisierul in zona de memorie
						Send(client2, lista[i].return3() + " " + lista[i].returnContinut());//trimit catre zona de memorie ce mi-a trimis clientul
				}
			}
		
		}
		
		SOCKET client = WaitForConnection(listening);
		if (client != INVALID_SOCKET) cout << "Client conectat!\n";

		if (client != INVALID_SOCKET)
		{
			int bytesReceived = 0;

			do {
				ZeroMemory(buf, MAX_BUFFER_SIZE);
				bytesReceived = recv(client, buf, MAX_BUFFER_SIZE, 0);
				closesocket(client);

				if (bytesReceived > 0)
				{
					if (MesajPrimit != NULL)
					{
						MesajPrimit(this, client, string(buf, 0, bytesReceived));

						this->HandleMessages(string(buf, 0, bytesReceived),bytesReceived,buf);
						//std::cout << string(buf, 0, bytesReceived) << endl;
					}
				}
			} while (bytesReceived > 0);
			/*if (!listaCatreClient.empty()) {
				//Send(client, listaCatreClient);
			}*/
			
			//->DisplayAllMessages();
		}
	}
	delete[] buf;
}




void CTCpListener::Cleanup()
{
	WSACleanup();
}

void CTCpListener::DisplayAllMessages()
{
	cout << "\nAcestea sunt toate mesajele care au fost trimise catre server:\n";
	for (int i = 0; i < lista.size(); i++)
		lista[i].print(), cout << endl;
}

	string CTCpListener::ReceiveCerere1() {

		vector<string> lista_master;
		ifstream f;
		f.open("listaMaster.txt");
		string buffer;
		if (f.is_open())
		{
			getline(f, buffer);
			while (!buffer.empty())
			{
				char* ch = new char[30];
				char* aux = _strdup(buffer.c_str());
				ch = strtok(aux, " ");//aici avem numele fisierelor
				lista_master.push_back(ch);
				getline(f, buffer);
			}
			f.close();
		}
		else
			cerr << "Eroare la deschiderea fiserului!!!\n";
		vector<string> listaAuxiliara;
		for (int i = 0; i < lista_master.size(); i++) {
			int j = 0;
			string cuvant;
			while (!isdigit(lista_master[i][j])) {
				cuvant+=(lista_master[i][j]);
				j++;
			}
			listaAuxiliara.push_back(cuvant);
		}
		vector<string> listaFinala;
		for (int i = 0; i < listaAuxiliara.size()-1; i++) {
			listaFinala.push_back(listaAuxiliara[i]);
			while (listaAuxiliara[i] == listaAuxiliara[i + 1])
			{
				if (i < listaAuxiliara.size() - 2)
				{
					i++;
				}
				else
					break;
			}
			//i--;
		}
		for (int i = 0; i < listaFinala.size(); i++)
		{
			listaFinala[i] += ".txt";
		}
		string listapentruClient;
		for (int i = 0; i < listaFinala.size(); i++)
		{
			listapentruClient += listaFinala[i] + "\n";
		}
		return listapentruClient;
	}
	void CTCpListener::ReceiveFile1( int bytesReceived, char* buf)
	{
		string s = buf;
		char* buf2 = _strdup(buf);
		char *ch=new char[20];
		ch = strtok(buf, " ");
		ch = strtok(NULL, " "); 
		int x = atoi(ch);
		
			ch = strtok(NULL, " ");
			string s1, s2, s3;
			s1 = ch;
			ch = strtok(NULL, " "); s2 = ch;
			ch = strtok(NULL, " "); s3 = ch;
			lista_master l(s1, s2, s3);
			string continut = s.substr(s1.size() + s2.size() + s3.size() + 7, 1024);
			lista.push_back(l);
			lista.back().AddContinut(continut);

		for (int i = 0; i < x-1; i++)
		{
			string ss = buf2;
			int y = 0;
			for (int j = 0; j < lista.size(); j++)
			{
				y=y+ lista[j].return3().size() + lista[j].returnContinut().size();
			}
			y += 7;
			y += i;
			string vv = ss.substr(y, ss.size()-y);
			string s1, s2, s3;
			char* alt = _strdup(vv.c_str());
			ch = strtok(alt, " ");
			s1 = ch;
			ch = strtok(NULL, " "); s2 = ch;
			ch = strtok(NULL, " "); s3 = ch;
			lista_master l(s1, s2, s3);
			string continut = vv.substr(s1.size() + s2.size() + s3.size()+i+2, 1024);
			lista.push_back(l);
			lista.back().AddContinut(continut);

		}
		ofstream f;
		f.open("listaMaster.txt", ios::app);
		if (f.is_open()) {
			for (int i = 0; i < lista.size(); i++)
			{
				f << lista[i].return3() << "\n";
			}
			f.close();
		}
		else
			cerr << "Eroare la deschiderea fisierului!\n";
	}
	

void CTCpListener::HandleMessages(string mesaj,int bytesReceived,char *buf)
{
	// Check if the message is a file upload request
	if (mesaj.substr(0,1) == "1") {//asta inseamna ca s-a primit un nume de fiser, val hash, zona mem aferenta si continut
	
		ReceiveFile1(bytesReceived,buf);
	}
	else if (mesaj.substr(0, 1) == "2")
	{
		listaCatreClient=ReceiveCerere1();// o sa trimitem lista catre client
		
	}
	else if (mesaj.substr(0, 1) == "3") {
		//trimitem catre zona de stocare o cerere
	}
}


SOCKET CTCpListener:: CreateSocket()
{
	SOCKET listening = socket(AF_INET, SOCK_STREAM, 0);
	if (listening != INVALID_SOCKET)
	{
		sockaddr_in hint;
		hint.sin_family = AF_INET;
		if (aux == 0)
		{
			hint.sin_port = htons(m_port1);
			aux++;
		}
		else hint.sin_port = htons(m_port2);

		inet_pton(AF_INET, m_ipAdress.c_str(), &hint.sin_addr);

		int reuse = 1;
		setsockopt(listening, SOL_SOCKET, SO_REUSEADDR, (const char*)&reuse, sizeof(reuse));

		int bindOK = bind(listening, (sockaddr*)&hint, sizeof(hint));
		if (bindOK != SOCKET_ERROR)
		{
			int listenOK = listen(listening, SOMAXCONN);
			if (listenOK == SOCKET_ERROR)
			{
				return -1;
			}
		}
		else
		{
			return -1;
		}
	}
	return listening;
}
SOCKET CTCpListener:: WaitForConnection(SOCKET listening) {
	SOCKET client = accept(listening, nullptr, nullptr);
	return client;
}