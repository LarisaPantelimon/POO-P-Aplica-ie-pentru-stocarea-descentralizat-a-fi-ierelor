#pragma once
#pragma warning(disable:4996)
#include<iostream>
#include<WS2tcpip.h>
#include<string>
#include<WS2tcpip.h>
#include<string>
#include<fstream>
#include"lista_master.h"
#include<vector>
#include <algorithm>
#include"ZonaDeMemorie1.cpp"
#include"ZonaDeMemorie2.cpp"
#include"ZonaDeMemorie3.cpp"
#include"ZonaDeMemorie4.cpp"
#pragma comment (lib,"ws2_32.lib")
using namespace std;

class ConectareServer
{
private:
    string ipAdress = "127.0.0.1";
    int port = 55000;

    //initializam winsock
    WSAData data;
    WORD ver = MAKEWORD(2, 2);
    int wsResult = WSAStartup(ver, &data);
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in hint;
    char buf[4096];
    string userInput;
    vector<lista_master> lista;

public:
    void Conectare() {
        if (wsResult != 0) {
            cerr << "Nu s-a putut porni winsock" << wsResult << endl;
            //return;
        }

        //creeam socket
        if (sock == INVALID_SOCKET) {
            cout << "Nu s-a putut creea socketul. Err #" << WSAGetLastError() << endl;
            WSACleanup();
            //return;
        }

        hint.sin_family = AF_INET;
        hint.sin_port = htons(port);
        inet_pton(AF_INET, ipAdress.c_str(), &hint.sin_addr);

        //conectam la server
        int connResult = connect(sock, (sockaddr*)&hint, sizeof(hint));
        if (connResult == SOCKET_ERROR)
        {
            cerr << "Nu s-a putut conecta la server!\n";
            closesocket(sock);
            WSACleanup();
            //return;
        }

        cout << "Aceasta este zona de memorie!\n";
        cout << "Aveti la dispozitie urmatoarele comenzi:\n";
        cout << "\t1.View: pentru vizualizarea tuturor fisierelor existente;\n";
        cout << "\t2.Delete: pentru stergerea unui fisier;\n";
        cout << "\t3.Daca nu doriti niciuna dintre comenzile de mai sus apasati orice tasta;\n";
        cout << "\n\n\t\t\tPentru a aceesa comenzile trebuie sa introduceti numele comenzii + argument in cazul comenzii 'Delete' !!!\n";
        do
        {

            getline(cin, userInput);
            if (userInput.size() > 0)
            {
                if (userInput == "View")
                {
                    vector<string> listaaditionala;
                    ifstream f;
                    f.open("listaMaster.txt");
                    if (f.is_open()) {
                        string buffer;
                        getline(f, buffer);
                        while (!buffer.empty()) {
                            listaaditionala.push_back(buffer);
                            cout << listaaditionala.back() << endl;
                            getline(f, buffer);
                        }

                        f.close();
                    }
                    else
                        cerr << "Eroare la deschiderea fisierului!\n";
                }
                else
                    if (userInput.find("Delete") != std::string::npos)// ATENTIE: SE POATE STERGE DOAR ELEMENT CU ELEMENT SI DOAR ULTIMUL DE LA COADA!!!
                    {
                        char *ch=new char[20];
                        char* comanda = _strdup(userInput.c_str());
                        ch = strtok(comanda, " ");
                        ch = strtok(NULL, " ");

                            vector<string> listaaditionala;
                            ifstream f;
                            f.open("listaMaster.txt");
                            if (f.is_open()) {
                                string buffer;
                                getline(f, buffer);
                                while (!buffer.empty()) {
                                    listaaditionala.push_back(buffer);
                                    cout << listaaditionala.back() << endl;
                                    getline(f, buffer);
                                }

                                f.close();
                            }
                            else
                                cerr << "Eroare la deschiderea fisierului!\n";
                            for (int i = 0; i < listaaditionala.size()-1; i++)
                            {
                                if (listaaditionala[i].find(ch) != std::string::npos)
                                {
                                    for (int j = 0; j < listaaditionala.size() - 1; j++)
                                        listaaditionala[j] = listaaditionala[j + 1];
                                    listaaditionala.pop_back();
                                }//daca nu se afla la finalul vectorului
                            }
                            if (listaaditionala[listaaditionala.size() - 1].find(ch) != std::string::npos)
                                listaaditionala.pop_back();//daca se afla la finalul vectorului

                            DeleteFromZonaDeMemorie1(ch);//se cauta si in zonele de memorie in vector si sterge
                            DeleteFromZonaDeMemorie2(ch);
                            DeleteFromZonaDeMemorie3(ch);
                            DeleteFromZonaDeMemorie4(ch);

                            ofstream fi;
                            fi.open("listaMaster.txt");

                            if (fi.is_open()) {
                                for (int i = 0; i < listaaditionala.size(); i++)
                                {
                                    fi << listaaditionala[i] << endl;
                                }
                                fi.close();
                            }
                            else
                                cerr << "Eroare la deschiderea fisierului!\n";

                    }
            }
                    else {
                        ZeroMemory(buf, 4096);
                        int bytesReceived = recv(sock, buf, 4096, 0);
                        string s;
                        if (bytesReceived > 0)
                        {
                            s = string(buf, 0, bytesReceived);
                            if (s.substr(0, 1) == "1")
                            {

                                char* buff = _strdup(buf); char* ch = new char[50];
                                ch=strtok(buff, " ");
                                ch = strtok(NULL, " ");//asta e numele fiserului pe care utilizatorul va vrea sa il descarce
                                string s = ch;
                                //prin asta ar trebui sa trimitem la server fisierul cerut
                                string continut=this->SearchInMemories(s);
                               int r= send(sock, continut.c_str(), continut.size()+1, 0);
                               if (r == SOCKET_ERROR) {
                                   cout << "Nu s-a putut trimite continutul!\n";
                               }
                               else cout << "\nTrimis cu succes!\n";

                            }
                            else
                                if (bytesReceived > 0)
                                {
                                    int aux = 1;
                                    cout << "SERVER> Message received!\n" << string(buf, 0, bytesReceived) << endl;
                                    this->HandleMesaje1(string(buf, 0, bytesReceived));
                                    this->RepartizareZonaDeMemorie();
                                }
                                else {
                                    cerr << "Failed to send message to server!\n";
                                    closesocket(sock);
                                    WSACleanup();
                                    //return;
                                }
                           
                        }
                    }
            
         }   while (true);
            closesocket(sock);
            WSACleanup();
        
    };

    void HandleMesaje1(string mesaj)
    {
        string s1, s2, s3;
        string special = mesaj;
        char* ch = new char[20];
        char* buffer = _strdup(mesaj.c_str());
        ch = strtok(buffer, " ");
        s1 = ch;
        ch = strtok(NULL, " ");
        s2 = ch;
        ch = strtok(NULL, " ");
        s3 = ch;
        char* ch2 = new char[4096];
        ch2 = strtok(NULL, " "); string s4 = special.substr(s1.size()+s2.size()+s3.size()+2,special.size());
        lista_master l(s1, s2, s3);
        lista.push_back(l);
        lista.back().AddContinut(s4);

        ofstream f;
        f.open("listaMaster.txt", ios::app);
        if (f.is_open()) {
           
            
                f << lista.back().return3() << "\n";
            
            f.close();
        }
        else
            cerr << "Eroare la deschiderea fisierului!\n";
    }

    void RepartizareZonaDeMemorie()
    {
       
            if (lista.back().returnZonaMem() == "ZonaDeMemorie1")
            {
                Write1(lista.back().returnNumeFisier(), lista.back().returnContinut());
            }
            if (lista.back().returnZonaMem() == "ZonaDeMemorie2")
            {
                Write2(lista.back().returnNumeFisier(), lista.back().returnContinut());
            }
            if (lista.back().returnZonaMem() == "ZonaDeMemorie3")
            {
                Write3(lista.back().returnNumeFisier(), lista.back().returnContinut());
            }
            if (lista.back().returnZonaMem() == "ZonaDeMemorie4")
            {
                Write4(lista.back().returnNumeFisier(), lista.back().returnContinut());
            }
    }
    string SearchInMemories(string n) {

        vector<string> v1,v2,v3,v4,vfin;
        string continutfinal;
        v1 = Search1(n);
        v2 = Search2(n);
        v3 = Search3(n);
        v4 = Search4(n);
        for (int i = 0; i < v1.size(); i++)
            vfin.push_back(v1[i]);
        for (int i = 0; i < v2.size(); i++)
            vfin.push_back(v2[i]);
        for (int i = 0; i < v3.size(); i++)
            vfin.push_back(v3[i]);
        for (int i = 0; i < v4.size(); i++)
            vfin.push_back(v4[i]);

        sort(vfin.begin(), vfin.end());

        for (int i = 0; i < vfin.size(); i++)
        {
            for (int j = 0; j < v1.size(); j++)
                if (vfin[i] == v1[j]) continutfinal += returneazaContinutAferent1(vfin[i]);
            for (int j = 0; j < v2.size(); j++)
                if (vfin[i] == v2[j]) continutfinal += returneazaContinutAferent1(vfin[i]);
            for (int j = 0; j < v3.size(); j++)
                if (vfin[i] == v3[j]) continutfinal += returneazaContinutAferent1(vfin[i]);
            for (int j = 0; j < v4.size(); j++)
                if (vfin[i] == v4[j]) continutfinal += returneazaContinutAferent1(vfin[i]);
        }
        return continutfinal;
    }
        
};