#include <iostream>
#include"PrimesteInfo.h"



int main()
{
    ConectareServer conect;
    conect.Conectare();
   
}
