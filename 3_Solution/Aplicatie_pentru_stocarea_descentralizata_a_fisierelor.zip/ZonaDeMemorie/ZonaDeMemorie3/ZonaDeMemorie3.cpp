#include "pch.h"
#include "framework.h"

#include<iostream>
#include<string>
#include<stdlib.h>
#include<fstream>
#include<vector>

using namespace std;
vector<string> fisiereExistente3;

void Write3(string numefisier, string continut)
{
   // fisiereExistente3.push_back(numefisier);//aici o sa retinem toate fisierele existente la nivelul zonei de mem 3
    ofstream f;
    f.open("C:/Users/larisa.pantelimon/Desktop/ZonaDeMemorie/ZonaDeMemorie3/fisiereExistente3.txt", ios::app);
    if (f.is_open()) {


        f << numefisier << "\n";

        f.close();
    }
    else
        cerr << "Eroare la deschiderea fisierului!\n";

    string s2 = "C:/Users/larisa.pantelimon/Desktop/ZonaDeMemorie/ZonaDeMemorie3/";
    numefisier = s2 + numefisier ;
    ofstream outputFile(numefisier); // Create the file

    if (outputFile.is_open()) {
        outputFile << continut; // Write data to the file
        outputFile.close(); // Close the file
    }
    else {
        cout << "Failed to create the file." <<endl;
    }
}
void DeleteFromZonaDeMemorie3(string n)
{
    vector<string> fis;
    ifstream f;
    f.open("C:/Users/larisa.pantelimon/Desktop/ZonaDeMemorie/ZonaDeMemorie3/fisiereExistente3.txt");
    if (f.is_open()) {
        string buffer;
        getline(f, buffer);
        while (!buffer.empty()) {
            fis.push_back(buffer);
            getline(f, buffer);
        }

        f.close();
    }
    else
        cerr << "Eroare la deschiderea fisierului!\n";

    for (int i = 0; i < fis.size() - 1; i++)
    {
        if (fis[i] == n)
            for (int j = 0; j < fis.size() - 1; j++)
                fis[i] = fis[i + 1];
        fis.pop_back();
    }
    if (fis[fis.size() - 1] == n)
        fis.pop_back();
    ofstream fi;
    fi.open("C:/Users/larisa.pantelimon/Desktop/ZonaDeMemorie/ZonaDeMemorie3/fisiereExistente3.txt");
    if (fi.is_open())
    {
        for (int i = 0; i < fis.size(); i++)
            fi << fis[i] << endl;
        fi.close();
    }
    else
        cerr << "Eroare la deschiderea fisierului!\n";

}
vector<string> Search3(string numeFisier)
{
    //ar trebui sa imi returneze denumirea fisierului si continutul aferent
    vector<string> returneaza;
    ifstream f;
    f.open("C:/Users/larisa.pantelimon/Desktop/ZonaDeMemorie/ZonaDeMemorie3/fisiereExistente3.txt");
    if (f.is_open()) {
        string buffer;
        getline(f, buffer);
        while (!buffer.empty()) {
            fisiereExistente3.push_back(buffer);
            getline(f, buffer);
        }

        f.close();
    }
    else
        cerr << "Eroare la deschiderea fisierului!\n";
    for (int i = 0; i < fisiereExistente3.size(); i++)
    {
        if (fisiereExistente3[i].find(numeFisier) != std::string::npos)
            returneaza.push_back(fisiereExistente3[i]);//daca am gasit fisere care au in componenta numele fiserului cautat le salvam
    }
    return returneaza;
}

string returneazaContinutAferent3(string n)
{
    string continut;
    n = n + ".txt";
    ifstream outputFile(n);

    if (outputFile.is_open())
    {
        string line;

        while (getline(outputFile, line))
        {
            continut = continut + line;
        }
        outputFile.close();
    }
    else
        cout << "Eroare la deschiderea mesajului!!!\n";

    return continut;
}
