#include "ccerere.h"

CCerere::CCerere()
{

}
