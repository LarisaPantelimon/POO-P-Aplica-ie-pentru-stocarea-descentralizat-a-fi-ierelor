#ifndef SOCKET_H
#define SOCKET_H

#endif // SOCKET_H
#include<iostream>
#include<WS2tcpip.h>
#include<string>
#include<WS2tcpip.h>
#include<string>
#include<fstream>
#include<QThread>
#include<QTextStream>
#pragma comment (lib,"ws2_32.lib")
#include <QApplication>
using namespace std;

class Socket
{protected:
    static Socket* instance;
    Socket();
    Socket(const Socket& s){};
    ~Socket();
public:
    static Socket& getInstance();
};
