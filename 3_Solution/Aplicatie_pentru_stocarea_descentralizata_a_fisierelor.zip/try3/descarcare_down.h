#ifndef DESCARCARE_DOWN_H
#define DESCARCARE_DOWN_H

#include "ccerere.h"

class Descarcare_down : public CCerere
{
public:
    Descarcare_down();
    Descarcare_down(string n){
        mesaj=n;
    }
    virtual void print() {int aux=1;}
    virtual string returnNume(){
        return mesaj;
    }
    ~Descarcare_down();
};

#endif // DESCARCARE_DOWN_H
