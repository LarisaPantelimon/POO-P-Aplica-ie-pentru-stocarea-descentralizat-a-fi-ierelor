#ifndef FEREASTRA3_H
#define FEREASTRA3_H
#include<iostream>
#include<WS2tcpip.h>
#include<string>
#include<WS2tcpip.h>
#include<string>
#include<fstream>
#include<QThread>
#include<QTextStream>
#include <functional>
#include <sstream>
#include"FactoryCerere.h"
#include "lista_down.h"
#pragma comment (lib,"ws2_32.lib")
#include <QApplication>
using namespace std;
#include <QDialog>

namespace Ui {
class fereastra3;
}

class fereastra3 : public QDialog
{
    Q_OBJECT
    string ipAdress = "127.0.0.1";
    int port = 55001;
    WSAData data;
    WORD ver = MAKEWORD(2, 2);
    int wsResult = WSAStartup(ver, &data);
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in hint;
    //conectam la server
    int connResult;

public:
    explicit fereastra3(QWidget *parent = nullptr);
    ~fereastra3();
    void Conectare(){
        hint.sin_family = AF_INET;
        hint.sin_port = htons(port);
        inet_pton(AF_INET, ipAdress.c_str(), &hint.sin_addr);


        //conectam la server
        connResult = ::connect(sock, (sockaddr*)&hint, sizeof(hint));
    }


private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::fereastra3 *ui;
    lista_down *fourthwindow;
    string listaDeLaServer;
};

#endif // FEREASTRA3_H
