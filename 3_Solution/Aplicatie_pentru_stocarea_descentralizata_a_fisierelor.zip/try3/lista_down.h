#ifndef LISTA_DOWN_H
#define LISTA_DOWN_H

#include <QDialog>
#include "qlistwidget.h"
namespace Ui {
class lista_down;
}

class lista_down : public QDialog
{
    Q_OBJECT

public:
    explicit lista_down(QWidget *parent = nullptr);
    ~lista_down();

private slots:
    void on_pushButton_clicked();

private:
    Ui::lista_down *ui;
};

#endif // LISTA_DOWN_H
