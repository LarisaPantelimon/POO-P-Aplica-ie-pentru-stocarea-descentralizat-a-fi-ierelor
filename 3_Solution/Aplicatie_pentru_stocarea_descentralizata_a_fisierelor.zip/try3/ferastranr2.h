#ifndef FERASTRANR2_H
#define FERASTRANR2_H

#include <QDialog>

namespace Ui {
class ferastranr2;
}

class ferastranr2 : public QDialog
{
    Q_OBJECT

public:
    explicit ferastranr2(QWidget *parent = nullptr);
    ~ferastranr2();

private:
    Ui::ferastranr2 *ui;
};

#endif // FERASTRANR2_H
