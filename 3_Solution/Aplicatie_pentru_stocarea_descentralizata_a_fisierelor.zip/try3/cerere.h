#ifndef CERERE_H
#define CERERE_H
#include<iostream>
#include<string>
#include<stdlib.h>

using namespace std;

class Cerere
{public:
   virtual void print()=0;
   virtual string returnNume()=0;
};

#endif // CERERE_H
