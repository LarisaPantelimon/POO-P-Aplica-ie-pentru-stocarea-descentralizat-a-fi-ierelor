#include "cerere.h"

Cerere::Cerere()
{

}
