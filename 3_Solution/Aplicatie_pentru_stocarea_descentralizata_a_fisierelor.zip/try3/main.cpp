#include "widget.h"
#include<iostream>
#include<WS2tcpip.h>
#include<string>
#include<WS2tcpip.h>
#include<string>
#include<fstream>
#include<QThread>
#include<QTextStream>
#pragma comment (lib,"ws2_32.lib")
#include <QApplication>
using namespace std;

int main(int argc, char *argv[])
{    QApplication a(argc, argv);
     Widget w;
     w.show();

     /*string ipAdress = "127.0.0.1";
     int port = 55001;

     //initializam winsock
     WSAData data;
     WORD ver = MAKEWORD(2, 2);
     int wsResult = WSAStartup(ver, &data);
     if (wsResult != 0) {
         cerr << "Nu s-a putut porni winsock" << wsResult << endl;
         //return;
     }

     //creeam socket
     SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
     if (sock == INVALID_SOCKET) {
         cout << "Nu s-a putut creea socketul. Err #" << WSAGetLastError() << endl;
         WSACleanup();
         //return;
     }

     //nu stiu ce
     sockaddr_in hint;
     hint.sin_family = AF_INET;
     hint.sin_port = htons(port);
     inet_pton(AF_INET, ipAdress.c_str(), &hint.sin_addr);

     //conectam la server
     int connResult = connect(sock, (sockaddr*)&hint, sizeof(hint));
     if (connResult == SOCKET_ERROR)
     {
         cerr << "Nu s-a putut conecta la server!\n";
         closesocket(sock);
         WSACleanup();
         //return;
     }

     //do-while loop pentru receive data
     char buf[4096];
     string userInput;
     //do {
//for
         userInput="1: fiser1 hvfskj4567 ZonaDeMemorie4";

         if (userInput.size() > 0)
         {
            int sendResult = send(sock, userInput.c_str(), userInput.size() + 1, 0);
            if (sendResult != SOCKET_ERROR)
            {
                ZeroMemory(buf, 4096);
                int bytesReceived = recv(sock, buf, 4096, 0);
                if (bytesReceived > 0)
                {
                    int aux=1;
                    //cout << "SERVER> Message received!\n";// << string(buf, 0, bytesReceived);
                }
                else {
                    cerr << "Failed to send message to server!\n";
                    closesocket(sock);
                    WSACleanup();
                    //return;
                }

            }
         }
         userInput="2: ultimuuuuul";

         if (userInput.size() > 0)
         {
            int sendResult = send(sock, userInput.c_str(), userInput.size() + 1, 0);
            if (sendResult != SOCKET_ERROR)
            {
                ZeroMemory(buf, 4096);
                int bytesReceived = recv(sock, buf, 4096, 0);
                if (bytesReceived > 0)
                {
                    int aux=1;
                    cout << "SERVER> Message received!\n";// << string(buf, 0, bytesReceived);
                }
                else {
                    cerr << "Failed to send message to server!\n";
                    closesocket(sock);
                    WSACleanup();
                    //return;
                }

            }
         }
         //} while (sock!=NULL);

         //inchidem tot
         closesocket(sock);
         WSACleanup();*/
     return a.exec();
}
