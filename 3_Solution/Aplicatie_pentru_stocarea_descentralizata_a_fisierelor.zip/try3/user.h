#ifndef USER_H
#define USER_H
#include <QDebug>
#include <QMessageBox>
#include <QFile>
#include <QTextStream>
#include <QDialog>

class User
{
private:
    QString nume,parola;
public:
    User(QString num,QString pass){nume=num,parola=pass;}
    QString get_nume(){return nume;}
    QString get_pass(){return parola;}
    void set_nume(QString num){nume=num;}
    void set_pass(QString pass){parola=pass;}
};

#endif // USER_H
