#include "fereastra3.h"
#include "ui_fereastra3.h"
#include <QApplication>
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QFileInfo>
#include <QDir>
#include <QTextStream>
#include <QChar> //pt isdigit
#include <QCoreApplication>
#include <QFile>
#include <QCryptographicHash>
#include <QDebug>
#include<fstream>

QByteArray calculateFileHash(const QString& filePath, QCryptographicHash::Algorithm hashAlgorithm)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly))
    {
        qDebug() << "Failed to open file:" << file.errorString();
        return QByteArray();
    }

    QCryptographicHash hash(hashAlgorithm);

    while (!file.atEnd())
    {
        QByteArray chunk = file.read(8192); // Read the file in chunks of 8192 bytes
        hash.addData(chunk);
    }

    file.close();

    return hash.result();
}
fereastra3::fereastra3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fereastra3)
{
    ui->setupUi(this);
}

fereastra3::~fereastra3()
{
    delete ui;
}

void fereastra3::on_pushButton_clicked()
{
    /*QString f=QFileDialog::getOpenFileName(this, //deschide fila
    tr("Open File"),
    "C://",
    "Text File (*.txt)"); //filtru pt text files
    QMessageBox::information(this,tr("File Name"),f); //message box cu numere fisierului deschis
    */
  /*  QString filters("Text files (*.txt)");
       QString defaultFilter("Text files (*.txt)");

        Static method approach
       QFileDialog::getSaveFileName(0, "Save file", QDir::homePath(),
           filters, &defaultFilter);
   */
    // selectarea fisierului pt salvare
   // QString fileName = QFileDialog::getOpenFileName(nullptr, "Selectaţi fişier",tr("Text files(*.txt)"));


  /*  QString fileName=QFileDialog::getOpenFileName(this, //deschide fila
        tr("Selectaţi fişier"),
        "C://",
        "Text File (*.txt)");
      if (fileName.isEmpty()) {
          qDebug() << "Fişier neselectat.";
          return ;
      }
      QString nume;
      for(int i=0;i<fileName.size();i++)
          if(fileName[i]=='/')
              nume.clear();
      else nume+=fileName[i];
      QString outputFileName = nume;
      QString outputPath = "D:/po_proiect/sim_upload/" + outputFileName; //aici se selecteaza folderul destinatie(pt stocare)
      QFile inputFile(fileName);
      QFile outputFile(outputPath);
      if (inputFile.open(QIODevice::ReadOnly) && outputFile.open(QIODevice::WriteOnly))
      {
          //copiază conţinutul din input in cel de output
          QByteArray data = inputFile.readAll();
          outputFile.write(data);
          inputFile.close();
          outputFile.close();
          qDebug() << "Fişier copiat cu succes pe " << outputPath;
      }
      else
      {
          qDebug() << "Deschidere nefinalizată.";
          return ;
      }
      */

    if (sock == INVALID_SOCKET) {
        cout << "Nu s-a putut creea socketul. Err #" << WSAGetLastError() << endl;
        WSACleanup();
        //return;
    }

    //nu stiu ce
    this->Conectare();
    if (connResult == SOCKET_ERROR)
    {
        cerr << "Nu s-a putut conecta la server!\n";
        closesocket(sock);
        WSACleanup();
        //return;
    }




QString fileName = QFileDialog::getOpenFileName(this,
    tr("Open File"), "",
    tr("Text Files (*.txt)"));
if (fileName.isEmpty()) {
    return;
} else {
    QFile file(fileName);
if (!file.open(QIODevice::ReadOnly)) {
    QMessageBox::information(this, tr("Nu s-a putut deschide fisierul"),
        file.errorString());
    return;
}
    QByteArray data = file.readAll();
    file.close();

    int marime_fis = 1024;
    int nr_fisiere = data.size() / marime_fis + (data.size() % marime_fis ? 1 : 0);
    QString nume = QFileInfo(file).completeBaseName();
    string nume_baza_fis=nume.toStdString();


    //QFile creare_pt_lista="D:/po_proiect/sim_lista/"+nume_baza_fis+".txt";// nu o sa ne mai trebuiasca se ocupa serverul
    QString director=QFileInfo(file).absolutePath()+"/"+nume+".txt";
    string dir=director.toStdString();
    qDebug()<<director;
    //QTextStream la_misto(&creare_pt_lista);
  //  la_misto<<creare_pt_lista.fileName(); // nu conteaza
   // la_misto.flush();
   //creare_pt_lista.close();
    string nume_trimis=nume_baza_fis;
    nume_baza_fis="D:/po_proiect/sim_lista/"+nume_baza_fis+".txt";
    string continut;
       ifstream outputFile(dir);

       if (outputFile.is_open())
       {
           string line;

           while (getline(outputFile, line))
           {
               continut = continut + line;
           }
           outputFile.close();
       }
       else
           cout << "Eroare la deschiderea mesajului!!!\n";

    //qDebug()<<"2";
   // QString z_stocare = "D:/po_proiect/sim_upload/";
    //QDir dir_baza(z_stocare); // obiect director de baza
    //string s2;
    int nr=continut.size();
    //aici o sa trimitem protocolul si numarul de fisiere
    string final="1: "+to_string(nr_fisiere)+" ";
    QString contii=QString::fromStdString(continut);
    qDebug()<<contii;

    for (int i = 0; i < nr_fisiere; ++i)
{
        //aici am numele bucatilor de fisier
    string nume_frag_curent = nume_trimis + to_string(i) + ".txt"; //creare fisiere de 1kb cu basename + id. lui
    //aici am zona de ememorie aferenta fiecarei bucati
    string s="ZonaDeMemorie" + to_string(i % 4 + 1);
    string s2; char constanta[1025];
    int alfa=0;
    for(int j=i*1024;j<(i+1)*1024;j++,alfa++)
    {
        constanta[alfa]=continut[j];
    }
    for(int j=alfa;j<1025;j++)
        constanta[j]='\0';

    s2=constanta;

    qDebug()<<QString::fromStdString(s2);

    string cont=s2;
    string inca=s2;
    hash<string> hasher;
        size_t hashValue = hasher(inca);

        stringstream ss;
        ss << hashValue;

        string s3=ss.str();//valoarea hash a continutului
         final=final+nume_frag_curent+" "+s3+" "+s+" "+s2+" ";
         s2.clear();

}

       int sendResult = send(sock, final.c_str(), final.size() + 1, 0);
       if (sendResult != SOCKET_ERROR)
       {
           qDebug()<<"trimis!";
       }
}
}



void fereastra3::on_pushButton_2_clicked()
{
    if (sock == INVALID_SOCKET) {
        cout << "Nu s-a putut creea socketul. Err #" << WSAGetLastError() << endl;
        WSACleanup();
        //return;
    }

    //nu stiu ce
    this->Conectare();
    if (connResult == SOCKET_ERROR)
    {
        cerr << "Nu s-a putut conecta la server!\n";
        closesocket(sock);
        WSACleanup();
        //return;
    }
    Cerere* c=FactoryCerere::createIntrareDown("2");

    int sendResult = send(sock, c->returnNume().c_str(), c->returnNume().size() + 1, 0);
    if (sendResult != SOCKET_ERROR)
    {
        qDebug()<<"trimis!";// prin asta am trimis la server cererea prin care sa ii spun ca vreau sa descarc un fiser din zona de stocare
    }
    char buf[4096];
    ZeroMemory(buf, 4096);

   int bytesReceived = recv(sock, buf, 4096, 0);
   qDebug()<<buf;
    if(bytesReceived>0){
        listaDeLaServer=buf;
    }
    qDebug()<<QString::fromStdString(listaDeLaServer);

    // deschidem primul folder al zonei de stocare(se incearca reintregirea dupa nume fara indice)
   /* QString fragment = QFileDialog::getOpenFileName(nullptr, "Alege primul fragment al fisierului","D:/po_proiect/sim_lista/", "Text files (*.txt)");
    QVector<QString> zone ={"ZonaDeMemorie1/","ZonaDeMemorie2/","ZonaDeMemorie3/","ZonaDeMemorie4/"}; //in while le folosesc pentru a schimba ZonaDeMemorie de stocare
    QString folder_baza="D:/po_proiect/sim_upload/";
    if (fragment.isEmpty()) {
        qDebug() << "Nu ati selectat fisier.";
        return ;
    }
    // !!P.S. Codul a fost facut initial pentru selectarea unui din fragmente, de acolo posibile linii de cod in plus
    // informatii despre fisier
    QFileInfo fragmentInfo(fragment);
    QString fragmentNumebaza = fragmentInfo.baseName(); //extrage nume de baza fara extensie
    int numar_fragment=0;
    int i=fragmentNumebaza.length();
    while (i > 0 && fragmentNumebaza[i-1].isDigit()) {
        fragmentNumebaza.chop(1); //sterge ultimele caractere care sunt cifre
        i--;
    }

    QFile outFile("D:/po_proiect/sim_downloads/"+fragmentNumebaza+".txt");
    QTextStream out(&outFile); //qtextstream e mai eficient
    if (!outFile.open(QIODevice::WriteOnly | QIODevice::Text)) {
        qDebug() << "Nu s-a putut deschide fisierul out.";
        return ;
    }

    int fragmentIndex=0;
    while(!fragment.isEmpty())
    {
        QFile fragfis(fragment);
        if(!fragfis.exists()) {
            qDebug() << "Fragmentul nu exista: " << fragment;
            break;
        }
        if (!fragfis.open(QIODevice::ReadOnly | QIODevice::Text)) {
            qDebug() << "Nu s-a putut deschide fragmentul pentru citire: " << fragment;
            break;
        }
        QTextStream in(&fragfis);
        out<<in.readAll();
        fragfis.close();
       // fragfis.remove(); (doar in caz de doresc dupa ce se descarca sa scap de fragmente)
        fragmentIndex+=1;
        fragment = "D:/po_proiect/sim_upload/"+ zone[fragmentIndex%4] + fragmentNumebaza + QString::fromStdString(std::to_string(fragmentIndex)) + ".txt";
    }
    out.flush(); // se asigura ca toate date sunt scrise in fisier si nu raman in buffer( caracteristica QTextStream)
    outFile.close();
    qDebug() << "Fisier concatenat ca "<< outFile.fileName();
    */
   fourthwindow=new lista_down(this);
   fourthwindow->show();
}

