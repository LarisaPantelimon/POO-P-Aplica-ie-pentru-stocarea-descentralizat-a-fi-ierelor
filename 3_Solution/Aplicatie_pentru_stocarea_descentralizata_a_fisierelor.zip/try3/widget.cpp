#include "widget.h"
#include "./ui_widget.h"
#include<iostream>
#include<WS2tcpip.h>
#include<string>
#include<WS2tcpip.h>
#include<string>
#include<fstream>
#include<QThread>
#include<QTextStream>
#pragma comment (lib,"ws2_32.lib")
#include <QApplication>
using namespace std;
Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_pushButton_clicked()
{
    QString nume = ui->login_nume->text();
    QString parola= ui->login_parola->text();
   //QFile f("D:\po_proiect\lista_utilizatori\utilizatori.txt");
    Utilizatori utiz("D:/po_proiect/lista_utilizatori/utilizatori.txt");//se da directorului fisierului de conturi

    if(utiz.found(nume,parola)==true)
        {
            QMessageBox::information(0,"info","Logare reuşită !");
            hide();
            thirdwindow=new fereastra3(this);
            thirdwindow->show();
        }
    else QMessageBox::warning(0,"info","Logare nereuşită !");

}


void Widget::on_pushButton_2_clicked()
{
    secondwindow= new fereastra2(this);
    secondwindow->show();

}

