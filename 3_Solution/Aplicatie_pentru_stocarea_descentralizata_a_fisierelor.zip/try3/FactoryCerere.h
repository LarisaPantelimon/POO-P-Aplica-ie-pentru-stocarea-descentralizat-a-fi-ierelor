#ifndef FACTORYCERERE_H
#define FACTORYCERERE_H
#include"descarcare_down.h"
#include"intrare_down.h"
#endif // FACTORYCERERE_H

class FactoryCerere{
public:
    static Cerere* createDescarcareDown(string n){
        return new Descarcare_down(n);
    }
    static Cerere* createIntrareDown(string n){
        return new Intrare_down(n);
    }
};
