#ifndef FEREASTRA2_H
#define FEREASTRA2_H
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QDialog>
#include <QMessageBox>
namespace Ui {
class fereastra2;
}

class fereastra2 : public QDialog
{
    Q_OBJECT

public:
    explicit fereastra2(QWidget *parent = nullptr);
    ~fereastra2();

private slots:
    void on_pushButton_clicked();

private:
    Ui::fereastra2 *ui;
};

#endif // FEREASTRA2_H
