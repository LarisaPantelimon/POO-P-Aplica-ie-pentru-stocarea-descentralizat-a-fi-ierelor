#include "ferastranr2.h"
#include "ui_ferastranr2.h"

ferastranr2::ferastranr2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ferastranr2)
{
    ui->setupUi(this);
}

ferastranr2::~ferastranr2()
{
    delete ui;
}
