#include "utilizator.h"

utilizator::utilizator()
{

}
