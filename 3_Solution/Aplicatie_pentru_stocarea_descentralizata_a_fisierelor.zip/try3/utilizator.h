#ifndef UTILIZATOR_H
#define UTILIZATOR_H

class utilizator
{
public:
    utilizator();
};

#endif // UTILIZATOR_H
