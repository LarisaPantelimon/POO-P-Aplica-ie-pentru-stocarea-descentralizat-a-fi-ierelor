#include "fereastra2.h"
#include "ui_fereastra2.h"

fereastra2::fereastra2(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fereastra2)
{
    ui->setupUi(this);
}

fereastra2::~fereastra2()
{
    delete ui;
}

void fereastra2::on_pushButton_clicked()
{
    QString nume = ui->inreg_nume->text();
    QString parola = ui->inreg_parola->text();
    QString verif_parola= ui->inreg_conf_parola->text();
    if(parola== verif_parola&& parola != ""&&nume!="")
        {
            qDebug() <<"Un user s-a putut înregistra.";
            QMessageBox::information(this,"Stare înregistrare","V-aţi înregistrat cu succes !",QMessageBox::Ok);
            QFile f("D:/po_proiect/lista_utilizatori/utilizatori.txt");
            if (!f.open(QIODevice::Append | QIODevice::Text)) //append pt scriere in continuarea fisierului
                QMessageBox::information(0,"info",f.errorString());
            QTextStream out(&f);
            out<<nume<<" "<<parola<<"\n";
             hide();
        }
        else
        {
            qDebug() <<"Un user nu s-a putut înregistra.";
            QMessageBox::warning(this,"Stare înregistrare","Înregistrare nefinalizată !",QMessageBox::Ok);
        }
}

