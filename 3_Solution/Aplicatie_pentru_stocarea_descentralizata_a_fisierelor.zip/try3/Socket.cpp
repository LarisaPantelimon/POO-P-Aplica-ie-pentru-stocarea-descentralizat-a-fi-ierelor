#include"Socket.h"
Socket* Socket::instance = nullptr;

Socket& Socket::getInstance()
{
    if (!Socket::instance)
    {
        Socket::instance = new Socket();
    }
    string ipAdress = "127.0.0.1";
    int port = 55001;

    //initializam winsock
    WSAData data;
    WORD ver = MAKEWORD(2, 2);
    int wsResult = WSAStartup(ver, &data);
    if (wsResult != 0) {
        cerr << "Nu s-a putut porni winsock" << wsResult << endl;
        //return;
    }

    //creeam socket
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) {
        cout << "Nu s-a putut creea socketul. Err #" << WSAGetLastError() << endl;
        WSACleanup();
        //return;
    }

    //nu stiu ce
    sockaddr_in hint;
    hint.sin_family = AF_INET;
    hint.sin_port = htons(port);
    inet_pton(AF_INET, ipAdress.c_str(), &hint.sin_addr);

    //conectam la server
    int connResult = ::connect(sock, (sockaddr*)&hint, sizeof(hint));
    if (connResult == SOCKET_ERROR)
    {
        cerr << "Nu s-a putut conecta la server!\n";
        closesocket(sock);
        WSACleanup();
        //return;
    }
    return (*Socket::instance);
}

void Socket::destroyInstance()
{
    if (Socket::instance)
    {
        delete Socket::instance;
        Socket::instance = nullptr;
    }
}
