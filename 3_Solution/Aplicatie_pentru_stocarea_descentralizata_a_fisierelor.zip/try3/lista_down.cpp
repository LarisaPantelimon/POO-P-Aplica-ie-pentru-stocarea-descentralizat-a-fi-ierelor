#include "lista_down.h"
#include "ui_lista_down.h"
#include <string.h>
lista_down::lista_down(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::lista_down)
{
    ui->setupUi(this);
    //aici adaugam numele fisierelor

    //for(int i=0;i<nr_fisiere;i++)
   //     ui->listWidget->addItem(nume_fisier);
}

lista_down::~lista_down()
{
    delete ui;
}

void lista_down::on_pushButton_clicked()
{
    //aici primim informatia despre fisierul selectat
    //string fisier_selectat= ui->listWidget->currentItem()->text();
}

