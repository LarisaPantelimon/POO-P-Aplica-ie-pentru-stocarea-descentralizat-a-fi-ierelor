#include "intrare_down.h"

Intrare_down::Intrare_down()
{

}
