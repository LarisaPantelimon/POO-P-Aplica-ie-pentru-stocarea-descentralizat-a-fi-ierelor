#ifndef INTRARE_DOWN_H
#define INTRARE_DOWN_H

#include "ccerere.h"

class Intrare_down : public CCerere
{
public:
    Intrare_down();
    Intrare_down(string n){
        mesaj=n;
    }
    virtual void print() {int aux=1;}
    virtual string returnNume(){
        return mesaj;
    }
    ~Intrare_down();
};

#endif // INTRARE_DOWN_H
