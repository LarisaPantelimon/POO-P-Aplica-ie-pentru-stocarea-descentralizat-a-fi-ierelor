#include "utilizatori.h"

Utilizatori::Utilizatori(QString filename)
{
    QFile f(filename);
    if (!f.open(QIODevice::ReadOnly))
        QMessageBox::information(0,"info",f.errorString());
    QTextStream in(&f);
    while(!in.atEnd())
    {   QString name,pass;
        QString linie=in.readLine();
        int i=0;
        for(;i<linie.size();i++)
            if(linie.at(i)==' ') break;
        else name+=linie.at(i);
        i++;
        for(;i<linie.size();i++)
            pass+=linie.at(i);
        this->adaugare(name,pass);
    }
}

bool Utilizatori::found(QString n, QString p)
{
    for(int i=0;i<nume.size();i++)
        if(n==nume[i]&&p==parole[i])
            return true;
    return false;
}
