#ifndef UTILIZATORI_H
#define UTILIZATORI_H

#include <QApplication>
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QString>
#include <QVector>
class Utilizatori
{
private:
    QVector<QString> nume,parole;
public:
    Utilizatori(QString filename);
    Utilizatori();
    ~Utilizatori(){nume.clear();parole.clear();}
    void adaugare(QString n,QString p){nume.push_back(n);parole.push_back(p);}
    bool found(QString n,QString p);
};

#endif // UTILIZATORI_H
