#ifndef CCERERE_H
#define CCERERE_H

#include "cerere.h"

class CCerere : public Cerere{
protected:
    string mesaj;
public:
    CCerere(){}
    CCerere(string n):mesaj(n){}
    virtual void print(){int aux=1;}
    virtual string returnNume(){
        return mesaj;
    }
    ~CCerere(){}
};

#endif // CCERERE_H
